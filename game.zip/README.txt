شغّل اللعبة باستخدام Python و Pygame:
python main.py