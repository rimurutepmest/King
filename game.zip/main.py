
import pygame
import random
import math

# --- الإعدادات الأساسية ---
WIDTH, HEIGHT = 800, 600
FPS = 60

# ألوان
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BROWN = (139, 69, 19)
PURPLE = (128, 0, 128)

# تهيئة Pygame
pygame.init()
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("لعبة مغامرة وتحدي")
clock = pygame.time.Clock()
font = pygame.font.SysFont("arial", 18)

# --- اللاعب ---
player = pygame.Rect(400, 300, 40, 40)
player_speed = 5
player_level = 1
player_xp = 0
player_health = 100
player_inventory = []

# --- وحوش ---
class Monster:
    def __init__(self):
        self.rect = pygame.Rect(random.randint(0, WIDTH - 40), random.randint(0, HEIGHT - 40), 40, 40)
        self.health = 30
        self.speed = 2

    def move_toward_player(self):
        dx, dy = player.x - self.rect.x, player.y - self.rect.y
        distance = math.hypot(dx, dy)
        if distance > 0:
            dx, dy = dx / distance, dy / distance
            self.rect.x += dx * self.speed
            self.rect.y += dy * self.speed

monsters = [Monster() for _ in range(5)]

# --- صناديق ---
chests = [pygame.Rect(random.randint(0, WIDTH - 40), random.randint(0, HEIGHT - 40), 30, 30) for _ in range(3)]

# --- زعماء ---
bosses = [pygame.Rect(100, 100, 60, 60), pygame.Rect(700, 500, 60, 60)]

# --- خريطة ---
current_area = "الغابة"

# --- وظائف مساعدة ---
def draw_window():
    win.fill(WHITE)
    pygame.draw.rect(win, GREEN, player)

    for m in monsters:
        pygame.draw.rect(win, RED, m.rect)

    for c in chests:
        pygame.draw.rect(win, BROWN, c)

    for b in bosses:
        pygame.draw.rect(win, PURPLE, b)

    # واجهة اللاعب
    ui = font.render(f"المستوى: {player_level} | XP: {player_xp} | الصحة: {player_health} | المنطقة: {current_area}", True, BLACK)
    win.blit(ui, (10, 10))
    pygame.display.update()

def handle_collisions():
    global player_xp, player_level, player_health
    for m in monsters[:]:
        if player.colliderect(m.rect):
            player_health -= 5
            m.health -= 10
            if m.health <= 0:
                monsters.remove(m)
                player_xp += 20
                if player_xp >= player_level * 50:
                    player_level += 1

    for c in chests[:]:
        if player.colliderect(c):
            item = random.choice(["سيف", "درع", "جرعة"])
            player_inventory.append(item)
            chests.remove(c)
            print(f"وجدت عنصر: {item}")

    for b in bosses:
        if player.colliderect(b):
            print("لقد واجهت زعيم! استعد للقتال!")
            player_health -= 20

# --- الحلقة الرئيسية ---
running = True
while running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.x -= player_speed
    if keys[pygame.K_RIGHT]:
        player.x += player_speed
    if keys[pygame.K_UP]:
        player.y -= player_speed
    if keys[pygame.K_DOWN]:
        player.y += player_speed

    for m in monsters:
        m.move_toward_player()

    handle_collisions()
    draw_window()

    if player_health <= 0:
        print("انتهت اللعبة! لقد خسرت.")
        running = False

pygame.quit()
